/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          950: "#0B1220",
          900: "#101826",
          800: "#182238",
          700: "#22304A",
          600: "#324260",
        },
        parchment: {
          50: "#FBF9F4",
          100: "#F6F1E7",
          200: "#ECE3D0",
        },
        brass: {
          400: "#D8AA5C",
          500: "#C08A34",
          600: "#9C6D26",
          700: "#7A5420",
        },
        teal: {
          400: "#4C9385",
          500: "#2F6F5E",
          600: "#235347",
          700: "#193C33",
        },
        rust: {
          500: "#B5493B",
          600: "#93392E",
        },
      },
      fontFamily: {
        display: ["'Source Serif 4'", "Georgia", "serif"],
        body: ["'Inter'", "system-ui", "sans-serif"],
        mono: ["'IBM Plex Mono'", "ui-monospace", "monospace"],
      },
      boxShadow: {
        card: "0 1px 2px rgba(16,24,38,0.06), 0 1px 12px rgba(16,24,38,0.05)",
      },
    },
  },
  plugins: [],
};
