# Meridian Assure — React Frontend

A React + Vite frontend for the Insurance Management System microservices
(`api-gateway`, `auth-service`, `customer-service`, `policy-service`,
`claim-service`, `support-service`, `notification-service`).

## Run it

```bash
npm install
cp .env.example .env      # edit VITE_API_BASE_URL if your gateway isn't on :8081
npm run dev
```

The app expects the **api-gateway** to be running (default `http://localhost:8081`)
with `discovery-server` and the backing services registered, since the gateway
routes everything with `lb://SERVICE-NAME`.

`npm run build` produces a static `dist/` you can serve from any static host or
behind nginx/the gateway itself.

## What's included

- **Auth** — login, register (with the two-track flow: `CUSTOMER`/`AGENT` get an
  account immediately, `ADMIN` signups go into a pending queue), forgot/reset
  password.
- **Overview** — role-aware dashboard with live counts.
- **Policy Catalog** — browse all policies; `ADMIN`/`MASTER_ADMIN` can create,
  edit, delete; `CUSTOMER` can purchase.
- **My Policies** — a customer's purchased policies, with renew/cancel.
- **Claims** — file a claim; `AGENT`/`ADMIN`/`MASTER_ADMIN` work the
  submitted → under review → approved/rejected → settled pipeline.
- **Customers** — directory CRUD for `AGENT`/`ADMIN`/`MASTER_ADMIN`.
- **Support Tickets** — raise a ticket; agents move it through
  open → in progress → resolved → closed.
- **Notifications** — send and view notifications by customer.
- **Admin Requests** — `MASTER_ADMIN` accepts/denies pending admin signups.

The visual language ("Meridian Assure") is a ledger/underwriting motif: ink
navy, brass, and parchment tones, a serif display face, and rubber-stamp-style
status badges for policy/claim/ticket states.

## A structural note on customer linking

`auth-service` (login identity) and `customer-service` (the `Customer` record
used everywhere else) are separate microservices with no shared foreign key —
a logged-in user isn't automatically tied to a `Customer` row. Until that's
addressed on the backend, this frontend has a `CUSTOMER` user enter their
`customerId` once (stored per-browser via `localStorage`) on the **My
Policies** page, and reuses it to scope "my policies / my claims / my
tickets" and to prefill purchase/claim/ticket forms. An agent or admin
creating the customer record can hand the customer their ID.

## Known API-gateway authorization gaps

While wiring this up against `GatewayRoutesConfig`/`SecurityConfig`, a few
routes fall through to the gateway's catch-all rule
(`.anyExchange().hasAuthority("ROLE_ADMIN")`) rather than an explicit rule for
the roles that clearly need them, for example:

- `POST/PUT/DELETE /customers/**` — only `ADMIN` passes, so `AGENT` (who the
  nav and UX otherwise treat as the customer-directory owner) will get a 403.
- `POST /notifications/send` and `GET /notifications/customer/**` — same
  catch-all, so only `ADMIN` can send/view notifications today.
- Policy catalog writes (`POST/PUT/DELETE /policies`) are `ADMIN`-only too,
  which is probably intended, but `MASTER_ADMIN` doesn't automatically inherit
  `ROLE_ADMIN`, so a master admin may also get 403s on these and on the plain
  `GET /policies` route.

The frontend handles this gracefully — failed calls surface a toast instead
of crashing — but the UI still shows the actions an `AGENT`/`MASTER_ADMIN`
would reasonably expect to use. Widening those `SecurityConfig` rules
(`api-gateway/src/main/java/.../config/SecurityConfig.java`) is a backend fix,
not something this frontend can work around.
