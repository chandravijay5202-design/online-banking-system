import { useEffect, useState } from "react";
import { ClaimAPI, extractErrorMessage } from "../api/client";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import { PageHeader, EmptyState, Loading, Money } from "../components/Ui";
import StatusStamp from "../components/StatusStamp";
import Modal from "../components/Modal";
import { formatDate, formatDateTime } from "../utils/format";
import { getLinkedCustomerId } from "../utils/customerLink";

const EMPTY_FORM = { customerId: "", purchaseId: "", claimReason: "", claimAmount: "", incidentDate: "" };

export default function Claims() {
  const { role, user } = useAuth();
  const toast = useToast();
  const isProcessor = role === "AGENT" || role === "ADMIN" || role === "MASTER_ADMIN";
  const canSubmit = role === "CUSTOMER" || role === "ADMIN" || role === "MASTER_ADMIN";

  const [claims, setClaims] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");

  const [submitOpen, setSubmitOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);

  const [remarksTarget, setRemarksTarget] = useState(null); // { claim, action }
  const [remarks, setRemarks] = useState("");
  const [acting, setActing] = useState(false);

  async function load() {
    setLoading(true);
    setLoadError("");
    try {
      if (isProcessor) {
        setClaims(await ClaimAPI.list());
      } else {
        const linked = getLinkedCustomerId(user?.username);
        if (linked) setClaims(await ClaimAPI.byCustomer(linked));
        else setClaims([]);
      }
    } catch (err) {
      setLoadError(extractErrorMessage(err, "Could not load claims."));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function openSubmit() {
    setForm({ ...EMPTY_FORM, customerId: getLinkedCustomerId(user?.username) || "" });
    setSubmitOpen(true);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSubmitting(true);
    try {
      await ClaimAPI.submit({
        ...form,
        customerId: Number(form.customerId),
        purchaseId: Number(form.purchaseId),
        claimAmount: Number(form.claimAmount),
      });
      toast.success("Claim submitted for review.");
      setSubmitOpen(false);
      load();
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not submit the claim."));
    } finally {
      setSubmitting(false);
    }
  }

  function openAction(claim, action) {
    setRemarksTarget({ claim, action });
    setRemarks("");
  }

  async function runAction() {
    if (!remarksTarget) return;
    const { claim, action } = remarksTarget;
    setActing(true);
    try {
      if (action === "review") await ClaimAPI.markUnderReview(claim.claimId);
      if (action === "approve") await ClaimAPI.approve(claim.claimId, remarks || undefined);
      if (action === "reject") await ClaimAPI.reject(claim.claimId, remarks || undefined);
      if (action === "settle") await ClaimAPI.settle(claim.claimId, remarks || undefined);
      toast.success("Claim updated.");
      setRemarksTarget(null);
      load();
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not update the claim."));
    } finally {
      setActing(false);
    }
  }

  const visible = statusFilter === "ALL" ? claims : claims.filter((c) => c.claimStatus === statusFilter);

  return (
    <div>
      <PageHeader
        eyebrow="Claims desk"
        title="Claims"
        action={
          canSubmit && (
            <button className="btn-brass" onClick={openSubmit}>+ File a claim</button>
          )
        }
      />

      <div className="flex flex-wrap gap-3 mb-5">
        <select className="field-input max-w-[12rem]" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="ALL">All statuses</option>
          {["SUBMITTED", "UNDER_REVIEW", "APPROVED", "REJECTED", "SETTLED"].map((s) => (
            <option key={s} value={s}>{s.replace("_", " ")}</option>
          ))}
        </select>
      </div>

      {loading ? (
        <Loading label="Loading claims" />
      ) : loadError ? (
        <EmptyState title="Couldn't load claims" hint={loadError} />
      ) : !isProcessor && !getLinkedCustomerId(user?.username) ? (
        <EmptyState title="Link your customer ID first" hint="Visit My Policies and enter your customer ID, then come back here." />
      ) : visible.length === 0 ? (
        <EmptyState title="No claims found" hint="Filed claims will appear here." />
      ) : (
        <div className="table-wrap">
          <table className="ledger">
            <thead>
              <tr>
                <th>Claim</th>
                <th>Reason</th>
                <th>Amount</th>
                <th>Incident</th>
                <th>Status</th>
                <th>Updated</th>
                {isProcessor && <th></th>}
              </tr>
            </thead>
            <tbody>
              {visible.map((c) => (
                <tr key={c.claimId}>
                  <td>
                    <div className="id-mono">#{c.claimId}</div>
                    <div className="text-xs text-ink-600/60">Purchase #{c.purchaseId} · Customer #{c.customerId}</div>
                  </td>
                  <td className="max-w-xs whitespace-normal text-sm">{c.claimReason}</td>
                  <td><Money value={c.claimAmount} /></td>
                  <td className="text-xs">{formatDate(c.incidentDate)}</td>
                  <td><StatusStamp status={c.claimStatus} /></td>
                  <td className="text-xs text-ink-600/60">{formatDateTime(c.updatedAt || c.submittedAt)}</td>
                  {isProcessor && (
                    <td>
                      <div className="flex gap-1.5 justify-end flex-wrap">
                        {c.claimStatus === "SUBMITTED" && (
                          <button className="btn-outline !py-1 !px-2 text-xs" onClick={() => openAction(c, "review")}>Review</button>
                        )}
                        {c.claimStatus === "UNDER_REVIEW" && (
                          <>
                            <button className="btn-brass !py-1 !px-2 text-xs" onClick={() => openAction(c, "approve")}>Approve</button>
                            <button className="btn-danger !py-1 !px-2 text-xs" onClick={() => openAction(c, "reject")}>Reject</button>
                          </>
                        )}
                        {c.claimStatus === "APPROVED" && (
                          <button className="btn-primary !py-1 !px-2 text-xs" onClick={() => openAction(c, "settle")}>Settle</button>
                        )}
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={submitOpen} onClose={() => setSubmitOpen(false)} title="File a new claim">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="field-label">Customer ID</label>
              <input
                type="number"
                className="field-input"
                value={form.customerId}
                onChange={(e) => setForm((f) => ({ ...f, customerId: e.target.value }))}
                required
              />
            </div>
            <div>
              <label className="field-label">Purchase ID</label>
              <input
                type="number"
                className="field-input"
                value={form.purchaseId}
                onChange={(e) => setForm((f) => ({ ...f, purchaseId: e.target.value }))}
                required
              />
            </div>
          </div>
          <div>
            <label className="field-label">Reason</label>
            <textarea
              className="field-input"
              rows={3}
              value={form.claimReason}
              onChange={(e) => setForm((f) => ({ ...f, claimReason: e.target.value }))}
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="field-label">Claim amount</label>
              <input
                type="number"
                min="0"
                step="0.01"
                className="field-input"
                value={form.claimAmount}
                onChange={(e) => setForm((f) => ({ ...f, claimAmount: e.target.value }))}
                required
              />
            </div>
            <div>
              <label className="field-label">Incident date</label>
              <input
                type="date"
                className="field-input"
                value={form.incidentDate}
                onChange={(e) => setForm((f) => ({ ...f, incidentDate: e.target.value }))}
                required
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" className="btn-ghost" onClick={() => setSubmitOpen(false)}>Cancel</button>
            <button type="submit" disabled={submitting} className="btn-brass">
              {submitting ? "Submitting…" : "Submit claim"}
            </button>
          </div>
        </form>
      </Modal>

      <Modal open={!!remarksTarget} onClose={() => setRemarksTarget(null)} title={`${remarksTarget?.action === "review" ? "Mark under review" : remarksTarget?.action === "approve" ? "Approve claim" : remarksTarget?.action === "reject" ? "Reject claim" : "Settle claim"} — Claim #${remarksTarget?.claim?.claimId ?? ""}`}>
        <div className="space-y-4">
          {remarksTarget?.action !== "review" && (
            <div>
              <label className="field-label">Remarks (optional)</label>
              <textarea className="field-input" rows={3} value={remarks} onChange={(e) => setRemarks(e.target.value)} />
            </div>
          )}
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" className="btn-ghost" onClick={() => setRemarksTarget(null)}>Cancel</button>
            <button type="button" disabled={acting} onClick={runAction} className="btn-primary">
              {acting ? "Saving…" : "Confirm"}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
