import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import { extractErrorMessage } from "../api/client";
import AuthShell from "../components/AuthShell";

const ROLES = [
  { value: "CUSTOMER", label: "Customer", hint: "Buy policies, file claims, raise tickets." },
  { value: "AGENT", label: "Agent", hint: "Manage customers and process claims." },
  { value: "ADMIN", label: "Admin", hint: "Requires approval from a master admin." },
];

export default function Register() {
  const { register } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: "", email: "", password: "", role: "CUSTOMER" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [pendingNotice, setPendingNotice] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setPendingNotice("");
    setBusy(true);
    try {
      const res = await register(form);
      if (!res.token) {
        // ADMIN registrations go into a pending queue for MASTER_ADMIN review.
        setPendingNotice(res.message || "Your admin registration request has been submitted for review.");
      } else {
        toast.success("Account created. Please sign in.");
        navigate("/login");
      }
    } catch (err) {
      setError(extractErrorMessage(err, "Registration failed."));
    } finally {
      setBusy(false);
    }
  }

  if (pendingNotice) {
    return (
      <AuthShell eyebrow="Almost there" title="Request submitted">
        <p className="text-sm text-ink-700 mb-6">{pendingNotice}</p>
        <Link to="/login" className="btn-primary w-full">Back to sign in</Link>
      </AuthShell>
    );
  }

  return (
    <AuthShell
      eyebrow="Open a ledger"
      title="Create your account"
      subtitle="Set up access for your role."
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="field-label" htmlFor="username">Username</label>
          <input
            id="username"
            className="field-input"
            placeholder="At least 3 characters, starts with a letter"
            value={form.username}
            onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))}
            required
          />
        </div>
        <div>
          <label className="field-label" htmlFor="email">Email</label>
          <input
            id="email"
            type="email"
            className="field-input"
            value={form.email}
            onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
            required
          />
        </div>
        <div>
          <label className="field-label" htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            className="field-input"
            placeholder="Upper, lower, number & symbol (@$!%*?&)"
            value={form.password}
            onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
            required
          />
        </div>
        <div>
          <span className="field-label">Role</span>
          <div className="grid grid-cols-1 gap-2">
            {ROLES.map((r) => (
              <label
                key={r.value}
                className={`flex items-start gap-3 rounded-md border px-3 py-2.5 cursor-pointer transition-colors ${
                  form.role === r.value
                    ? "border-brass-500 bg-brass-500/5"
                    : "border-ink-900/15 hover:bg-ink-900/[0.03]"
                }`}
              >
                <input
                  type="radio"
                  name="role"
                  className="mt-1"
                  checked={form.role === r.value}
                  onChange={() => setForm((f) => ({ ...f, role: r.value }))}
                />
                <span>
                  <span className="block text-sm font-medium text-ink-900">{r.label}</span>
                  <span className="block text-xs text-ink-600/70">{r.hint}</span>
                </span>
              </label>
            ))}
          </div>
        </div>
        {error && <p className="field-error">{error}</p>}
        <button type="submit" disabled={busy} className="btn-primary w-full">
          {busy ? "Creating account…" : "Create account"}
        </button>
      </form>

      <p className="mt-5 text-center text-sm text-ink-700/70">
        Already registered? <Link to="/login" className="hover:text-brass-600 font-medium">Sign in</Link>
      </p>
    </AuthShell>
  );
}
