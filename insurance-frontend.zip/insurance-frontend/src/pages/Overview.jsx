import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { CustomerAPI, PolicyAPI, ClaimAPI, SupportAPI } from "../api/client";
import { useAuth } from "../context/AuthContext";
import { Loading } from "../components/Ui";
import { getLinkedCustomerId } from "../utils/customerLink";

function StatCard({ label, value, hint, to }) {
  const body = (
    <div className="card p-5 h-full">
      <div className="text-[10px] uppercase tracking-widest text-ink-600/60 font-semibold">{label}</div>
      <div className="font-display text-3xl mt-1.5">{value}</div>
      {hint && <div className="text-xs text-ink-600/60 mt-1">{hint}</div>}
    </div>
  );
  return to ? <Link to={to}>{body}</Link> : body;
}

export default function Overview() {
  const { user, role } = useAuth();
  const isProcessor = role === "AGENT" || role === "ADMIN" || role === "MASTER_ADMIN";
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ customers: null, policies: null, claims: null, tickets: null });

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      const linked = getLinkedCustomerId(user?.username);

      const [customers, policies, claims, tickets] = await Promise.allSettled([
        isProcessor ? CustomerAPI.list() : Promise.resolve(null),
        PolicyAPI.list(),
        isProcessor ? ClaimAPI.list() : linked ? ClaimAPI.byCustomer(linked) : Promise.resolve([]),
        isProcessor ? SupportAPI.list() : linked ? SupportAPI.byCustomer(linked) : Promise.resolve([]),
      ]);

      if (cancelled) return;
      setStats({
        customers: customers.status === "fulfilled" ? customers.value?.length ?? null : null,
        policies: policies.status === "fulfilled" ? policies.value.length : null,
        claims: claims.status === "fulfilled" ? claims.value : null,
        tickets: tickets.status === "fulfilled" ? tickets.value : null,
      });
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const openClaims = stats.claims?.filter((c) => c.claimStatus === "SUBMITTED" || c.claimStatus === "UNDER_REVIEW").length;
  const openTickets = stats.tickets?.filter((t) => t.ticketStatus === "OPEN" || t.ticketStatus === "IN_PROGRESS").length;

  return (
    <div>
      <div className="mb-8">
        <div className="text-xs font-mono uppercase tracking-widest text-brass-600 mb-1">
          {new Date().toLocaleDateString("en-IN", { weekday: "long", month: "long", day: "numeric" })}
        </div>
        <h1 className="text-2xl md:text-3xl font-semibold">
          Welcome back, {user?.username}
          <span className="stamp stamp-neutral ml-3 align-middle">{role}</span>
        </h1>
      </div>

      {loading ? (
        <Loading label="Pulling the ledger" />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {isProcessor && (
            <StatCard label="Customers on file" value={stats.customers ?? "—"} to="/app/customers" />
          )}
          <StatCard label="Policies in catalog" value={stats.policies ?? "—"} to="/app/policies" />
          <StatCard
            label={isProcessor ? "Open claims" : "My claims in progress"}
            value={openClaims ?? "—"}
            hint={stats.claims ? `${stats.claims.length} total` : undefined}
            to="/app/claims"
          />
          <StatCard
            label={isProcessor ? "Open tickets" : "My open tickets"}
            value={openTickets ?? "—"}
            hint={stats.tickets ? `${stats.tickets.length} total` : undefined}
            to="/app/support"
          />
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
        <div className="card p-6">
          <h3 className="font-display text-lg mb-2">
            {role === "CUSTOMER" ? "Getting started" : "Today's queue"}
          </h3>
          {role === "CUSTOMER" ? (
            <ul className="text-sm text-ink-700/80 space-y-1.5 list-disc pl-4">
              <li>Browse the <Link to="/app/policies" className="text-brass-600 hover:underline">policy catalog</Link> and purchase your first plan.</li>
              <li>Link your customer ID on <Link to="/app/my-policies" className="text-brass-600 hover:underline">My Policies</Link> to see everything tied to your account.</li>
              <li>File a claim or raise a support ticket any time — we'll route it to the right desk.</li>
            </ul>
          ) : (
            <ul className="text-sm text-ink-700/80 space-y-1.5 list-disc pl-4">
              <li>Review claims sitting in <em>Submitted</em> or <em>Under review</em>.</li>
              <li>Work through open support tickets, oldest first.</li>
              {role === "MASTER_ADMIN" && (
                <li>Check the <Link to="/app/admin-requests" className="text-brass-600 hover:underline">admin request queue</Link> for pending sign-ups.</li>
              )}
            </ul>
          )}
        </div>

        <div className="card p-6">
          <h3 className="font-display text-lg mb-2">System map</h3>
          <p className="text-sm text-ink-700/80">
            Meridian Assure is stitched together from six services behind a single gateway: auth, customers, policies, claims, support and notifications.
            Every request you make here carries your signed-in role as a bearer token.
          </p>
        </div>
      </div>
    </div>
  );
}
