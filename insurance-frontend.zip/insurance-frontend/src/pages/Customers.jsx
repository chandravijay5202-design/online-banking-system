import { useEffect, useMemo, useState } from "react";
import { CustomerAPI, extractErrorMessage } from "../api/client";
import { useToast } from "../context/ToastContext";
import { PageHeader, EmptyState, Loading } from "../components/Ui";
import Modal from "../components/Modal";

const EMPTY_FORM = { firstName: "", lastName: "", email: "", phone: "", address: "" };

export default function Customers() {
  const toast = useToast();
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    try {
      setCustomers(await CustomerAPI.list());
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not load customers."));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    if (!query) return customers;
    const q = query.toLowerCase();
    return customers.filter(
      (c) =>
        `${c.firstName} ${c.lastName}`.toLowerCase().includes(q) ||
        c.email?.toLowerCase().includes(q) ||
        String(c.customerId).includes(q)
    );
  }, [customers, query]);

  function openCreate() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setModalOpen(true);
  }

  function openEdit(c) {
    setEditing(c);
    setForm({ firstName: c.firstName, lastName: c.lastName, email: c.email, phone: c.phone || "", address: c.address || "" });
    setModalOpen(true);
  }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    try {
      if (editing) {
        await CustomerAPI.update(editing.customerId, form);
        toast.success("Customer updated.");
      } else {
        const created = await CustomerAPI.create(form);
        toast.success(`Customer #${created.customerId} created.`);
      }
      setModalOpen(false);
      load();
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not save this customer."));
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(c) {
    if (!window.confirm(`Delete ${c.firstName} ${c.lastName}? This cannot be undone.`)) return;
    try {
      await CustomerAPI.remove(c.customerId);
      toast.success("Customer deleted.");
      load();
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not delete this customer."));
    }
  }

  return (
    <div>
      <PageHeader
        eyebrow="Directory"
        title="Customers"
        action={<button className="btn-brass" onClick={openCreate}>+ New customer</button>}
      />

      <input
        className="field-input max-w-sm mb-5"
        placeholder="Search by name, email or ID…"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />

      {loading ? (
        <Loading label="Loading customers" />
      ) : filtered.length === 0 ? (
        <EmptyState title="No customers found" hint="Add your first customer to get started." />
      ) : (
        <div className="table-wrap">
          <table className="ledger">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((c) => (
                <tr key={c.customerId}>
                  <td className="id-mono">#{c.customerId}</td>
                  <td className="font-medium text-ink-900">{c.firstName} {c.lastName}</td>
                  <td>{c.email}</td>
                  <td>{c.phone || "—"}</td>
                  <td className="max-w-[16rem] whitespace-normal text-sm text-ink-700/80">{c.address || "—"}</td>
                  <td>
                    <div className="flex gap-2 justify-end">
                      <button className="btn-outline !py-1 !px-2 text-xs" onClick={() => openEdit(c)}>Edit</button>
                      <button className="btn-danger !py-1 !px-2 text-xs" onClick={() => handleDelete(c)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit customer" : "New customer"}>
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="field-label">First name</label>
              <input className="field-input" value={form.firstName} onChange={(e) => setForm((f) => ({ ...f, firstName: e.target.value }))} required />
            </div>
            <div>
              <label className="field-label">Last name</label>
              <input className="field-input" value={form.lastName} onChange={(e) => setForm((f) => ({ ...f, lastName: e.target.value }))} required />
            </div>
          </div>
          <div>
            <label className="field-label">Email</label>
            <input type="email" className="field-input" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} required />
          </div>
          <div>
            <label className="field-label">Phone</label>
            <input className="field-input" value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} />
          </div>
          <div>
            <label className="field-label">Address</label>
            <textarea className="field-input" rows={2} value={form.address} onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))} />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" className="btn-ghost" onClick={() => setModalOpen(false)}>Cancel</button>
            <button type="submit" disabled={saving} className="btn-primary">
              {saving ? "Saving…" : editing ? "Save changes" : "Create customer"}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
