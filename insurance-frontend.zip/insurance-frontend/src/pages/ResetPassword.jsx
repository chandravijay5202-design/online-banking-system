import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { AuthAPI, extractErrorMessage } from "../api/client";
import { useToast } from "../context/ToastContext";
import AuthShell from "../components/AuthShell";

export default function ResetPassword() {
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ token: location.state?.token || "", newPassword: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      await AuthAPI.resetPassword(form);
      toast.success("Password reset. Please sign in.");
      navigate("/login");
    } catch (err) {
      setError(extractErrorMessage(err, "Could not reset password."));
    } finally {
      setBusy(false);
    }
  }

  return (
    <AuthShell
      eyebrow="Password recovery"
      title="Set a new password"
      subtitle="Paste the reset token you were issued."
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="field-label" htmlFor="token">Reset token</label>
          <textarea
            id="token"
            rows={3}
            className="field-input font-mono text-xs"
            value={form.token}
            onChange={(e) => setForm((f) => ({ ...f, token: e.target.value }))}
            required
          />
        </div>
        <div>
          <label className="field-label" htmlFor="newPassword">New password</label>
          <input
            id="newPassword"
            type="password"
            className="field-input"
            placeholder="Upper, lower, number & symbol (@$!%*?&)"
            value={form.newPassword}
            onChange={(e) => setForm((f) => ({ ...f, newPassword: e.target.value }))}
            required
          />
        </div>
        {error && <p className="field-error">{error}</p>}
        <button type="submit" disabled={busy} className="btn-primary w-full">
          {busy ? "Resetting…" : "Reset password"}
        </button>
      </form>
      <p className="mt-5 text-center text-sm text-ink-700/70">
        <Link to="/login" className="hover:text-brass-600 font-medium">Back to sign in</Link>
      </p>
    </AuthShell>
  );
}
