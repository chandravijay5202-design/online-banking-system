import { useEffect, useState } from "react";
import { NotificationAPI, extractErrorMessage } from "../api/client";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import { PageHeader, EmptyState, Loading } from "../components/Ui";
import { formatDateTime } from "../utils/format";
import { getLinkedCustomerId, setLinkedCustomerId } from "../utils/customerLink";

export default function Notifications() {
  const { role, user } = useAuth();
  const toast = useToast();
  const canSend = role === "AGENT" || role === "ADMIN" || role === "MASTER_ADMIN";

  const [customerId, setCustomerId] = useState(getLinkedCustomerId(user?.username) || "");
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);

  const [sendForm, setSendForm] = useState({ customerId: "", message: "", type: "EMAIL" });
  const [sending, setSending] = useState(false);

  async function load(id) {
    if (!id) return;
    setLoading(true);
    try {
      setItems(await NotificationAPI.byCustomer(id));
      setLoaded(true);
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not load notifications."));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (customerId) load(customerId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function handleLookup(e) {
    e.preventDefault();
    setLinkedCustomerId(user?.username, customerId);
    load(customerId);
  }

  async function handleSend(e) {
    e.preventDefault();
    setSending(true);
    try {
      await NotificationAPI.send({ ...sendForm, customerId: Number(sendForm.customerId) });
      toast.success("Notification sent.");
      setSendForm({ customerId: "", message: "", type: "EMAIL" });
      if (String(sendForm.customerId) === String(customerId)) load(customerId);
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not send the notification."));
    } finally {
      setSending(false);
    }
  }

  return (
    <div>
      <PageHeader eyebrow="Inbox" title="Notifications" />

      {canSend && (
        <div className="card p-5 mb-6">
          <h3 className="font-display text-lg mb-3">Send a notification</h3>
          <form onSubmit={handleSend} className="grid grid-cols-1 md:grid-cols-[8rem_1fr_8rem_auto] gap-3 items-end">
            <div>
              <label className="field-label">Customer ID</label>
              <input
                type="number"
                className="field-input"
                value={sendForm.customerId}
                onChange={(e) => setSendForm((f) => ({ ...f, customerId: e.target.value }))}
                required
              />
            </div>
            <div>
              <label className="field-label">Message</label>
              <input
                className="field-input"
                value={sendForm.message}
                onChange={(e) => setSendForm((f) => ({ ...f, message: e.target.value }))}
                required
              />
            </div>
            <div>
              <label className="field-label">Channel</label>
              <select className="field-input" value={sendForm.type} onChange={(e) => setSendForm((f) => ({ ...f, type: e.target.value }))}>
                <option value="EMAIL">Email</option>
                <option value="SMS">SMS</option>
              </select>
            </div>
            <button type="submit" disabled={sending} className="btn-brass">
              {sending ? "Sending…" : "Send"}
            </button>
          </form>
        </div>
      )}

      <div className="card p-5 mb-6">
        <form onSubmit={handleLookup} className="flex flex-wrap items-end gap-3">
          <div>
            <label className="field-label">Customer ID</label>
            <input type="number" className="field-input w-40" value={customerId} onChange={(e) => setCustomerId(e.target.value)} required />
          </div>
          <button type="submit" className="btn-outline">View notifications</button>
        </form>
      </div>

      {loading ? (
        <Loading label="Loading notifications" />
      ) : !loaded ? (
        <EmptyState title="Enter a customer ID above" hint="We'll show every notification sent to that customer." />
      ) : items.length === 0 ? (
        <EmptyState title="No notifications yet" />
      ) : (
        <div className="grid grid-cols-1 gap-3">
          {items.map((n, i) => (
            <div key={n.notificationId || i} className="card p-4 flex items-start justify-between gap-3">
              <div>
                <div className="text-[10px] font-mono uppercase tracking-widest text-brass-600">{n.type || "EMAIL"}</div>
                <p className="text-sm text-ink-800 mt-1">{n.message}</p>
              </div>
              <span className="text-xs text-ink-600/50 shrink-0 font-mono">{formatDateTime(n.sentAt || n.createdAt)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
