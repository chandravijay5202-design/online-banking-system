import { useEffect, useState } from "react";
import { SupportAPI, extractErrorMessage } from "../api/client";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import { PageHeader, EmptyState, Loading } from "../components/Ui";
import StatusStamp from "../components/StatusStamp";
import Modal from "../components/Modal";
import { formatDateTime } from "../utils/format";
import { getLinkedCustomerId } from "../utils/customerLink";

const PRIORITIES = ["LOW", "MEDIUM", "HIGH", "CRITICAL"];
const EMPTY_FORM = { customerId: "", subject: "", description: "", priority: "MEDIUM" };

export default function Support() {
  const { role, user } = useAuth();
  const toast = useToast();
  const isAgent = role === "AGENT" || role === "ADMIN" || role === "MASTER_ADMIN";
  const canCreate = role === "CUSTOMER" || role === "ADMIN" || role === "MASTER_ADMIN";

  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");

  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);

  const [remarksTarget, setRemarksTarget] = useState(null); // { ticket, action }
  const [remarks, setRemarks] = useState("");
  const [acting, setActing] = useState(false);

  async function load() {
    setLoading(true);
    setLoadError("");
    try {
      if (isAgent) {
        setTickets(await SupportAPI.list());
      } else {
        const linked = getLinkedCustomerId(user?.username);
        if (linked) setTickets(await SupportAPI.byCustomer(linked));
        else setTickets([]);
      }
    } catch (err) {
      setLoadError(extractErrorMessage(err, "Could not load tickets."));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function openCreate() {
    setForm({ ...EMPTY_FORM, customerId: getLinkedCustomerId(user?.username) || "" });
    setCreateOpen(true);
  }

  async function handleCreate(e) {
    e.preventDefault();
    setSubmitting(true);
    try {
      await SupportAPI.create({ ...form, customerId: Number(form.customerId) });
      toast.success("Ticket raised. Our team will pick it up shortly.");
      setCreateOpen(false);
      load();
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not raise the ticket."));
    } finally {
      setSubmitting(false);
    }
  }

  function openAction(ticket, action) {
    setRemarksTarget({ ticket, action });
    setRemarks("");
  }

  async function runAction() {
    if (!remarksTarget) return;
    const { ticket, action } = remarksTarget;
    setActing(true);
    try {
      if (action === "in-progress") await SupportAPI.markInProgress(ticket.ticketId, remarks || undefined);
      if (action === "resolve") await SupportAPI.resolve(ticket.ticketId, remarks || undefined);
      if (action === "close") await SupportAPI.close(ticket.ticketId, remarks || undefined);
      toast.success("Ticket updated.");
      setRemarksTarget(null);
      load();
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not update the ticket."));
    } finally {
      setActing(false);
    }
  }

  return (
    <div>
      <PageHeader
        eyebrow="Help desk"
        title="Support Tickets"
        action={canCreate && <button className="btn-brass" onClick={openCreate}>+ Raise a ticket</button>}
      />

      {loading ? (
        <Loading label="Loading tickets" />
      ) : loadError ? (
        <EmptyState title="Couldn't load tickets" hint={loadError} />
      ) : !isAgent && !getLinkedCustomerId(user?.username) ? (
        <EmptyState title="Link your customer ID first" hint="Visit My Policies and enter your customer ID, then come back here." />
      ) : tickets.length === 0 ? (
        <EmptyState title="No tickets found" hint="Raised tickets will appear here." />
      ) : (
        <div className="grid grid-cols-1 gap-3">
          {tickets.map((t) => (
            <div key={t.ticketId} className="card p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="id-mono">#{t.ticketId}</span>
                    <span className={`stamp -rotate-0 ${
                      t.priority === "CRITICAL" ? "stamp-negative" : t.priority === "HIGH" ? "stamp-pending" : "stamp-neutral"
                    }`}>{t.priority}</span>
                    <StatusStamp status={t.ticketStatus} />
                  </div>
                  <h3 className="font-display text-lg mt-1.5">{t.subject}</h3>
                  <p className="text-sm text-ink-700/80 mt-1 max-w-2xl">{t.description}</p>
                  {t.remarks && (
                    <p className="text-xs text-ink-600/70 mt-2 italic">Remarks: {t.remarks}</p>
                  )}
                  <p className="text-[11px] text-ink-600/50 mt-2 font-mono">
                    Customer #{t.customerId} · opened {formatDateTime(t.createdAt)}
                  </p>
                </div>
                {isAgent && (
                  <div className="flex gap-1.5 flex-wrap shrink-0">
                    {t.ticketStatus === "OPEN" && (
                      <button className="btn-outline !py-1 !px-2 text-xs" onClick={() => openAction(t, "in-progress")}>Start work</button>
                    )}
                    {(t.ticketStatus === "OPEN" || t.ticketStatus === "IN_PROGRESS") && (
                      <button className="btn-brass !py-1 !px-2 text-xs" onClick={() => openAction(t, "resolve")}>Resolve</button>
                    )}
                    {t.ticketStatus === "RESOLVED" && (
                      <button className="btn-primary !py-1 !px-2 text-xs" onClick={() => openAction(t, "close")}>Close</button>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={createOpen} onClose={() => setCreateOpen(false)} title="Raise a support ticket">
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="field-label">Customer ID</label>
            <input
              type="number"
              className="field-input"
              value={form.customerId}
              onChange={(e) => setForm((f) => ({ ...f, customerId: e.target.value }))}
              required
            />
          </div>
          <div>
            <label className="field-label">Subject</label>
            <input className="field-input" value={form.subject} onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))} required />
          </div>
          <div>
            <label className="field-label">Description</label>
            <textarea className="field-input" rows={4} value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} required />
          </div>
          <div>
            <label className="field-label">Priority</label>
            <select className="field-input" value={form.priority} onChange={(e) => setForm((f) => ({ ...f, priority: e.target.value }))}>
              {PRIORITIES.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" className="btn-ghost" onClick={() => setCreateOpen(false)}>Cancel</button>
            <button type="submit" disabled={submitting} className="btn-brass">
              {submitting ? "Raising…" : "Raise ticket"}
            </button>
          </div>
        </form>
      </Modal>

      <Modal
        open={!!remarksTarget}
        onClose={() => setRemarksTarget(null)}
        title={`${remarksTarget?.action === "in-progress" ? "Start work on" : remarksTarget?.action === "resolve" ? "Resolve" : "Close"} ticket #${remarksTarget?.ticket?.ticketId ?? ""}`}
      >
        <div className="space-y-4">
          <div>
            <label className="field-label">Remarks (optional)</label>
            <textarea className="field-input" rows={3} value={remarks} onChange={(e) => setRemarks(e.target.value)} />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" className="btn-ghost" onClick={() => setRemarksTarget(null)}>Cancel</button>
            <button type="button" disabled={acting} onClick={runAction} className="btn-primary">
              {acting ? "Saving…" : "Confirm"}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
