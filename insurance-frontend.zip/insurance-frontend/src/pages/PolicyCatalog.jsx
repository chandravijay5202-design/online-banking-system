import { useEffect, useMemo, useState } from "react";
import { PolicyAPI, extractErrorMessage } from "../api/client";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import { PageHeader, EmptyState, Loading, Money } from "../components/Ui";
import Modal from "../components/Modal";
import { getLinkedCustomerId } from "../utils/customerLink";

const POLICY_TYPES = ["HEALTH", "AUTO", "LIFE", "HOME"];
const EMPTY_FORM = { policyName: "", policyType: "HEALTH", description: "", basePremiumAmount: "", coverageAmount: "" };

export default function PolicyCatalog() {
  const { role, user } = useAuth();
  const toast = useToast();
  const canManage = role === "ADMIN" || role === "MASTER_ADMIN";
  const canPurchase = role === "CUSTOMER";

  const [policies, setPolicies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [typeFilter, setTypeFilter] = useState("ALL");
  const [query, setQuery] = useState("");

  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const [purchaseOpen, setPurchaseOpen] = useState(false);
  const [purchaseTarget, setPurchaseTarget] = useState(null);
  const [purchaseForm, setPurchaseForm] = useState({ customerId: "", startDate: "", endDate: "" });
  const [purchasing, setPurchasing] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const data = await PolicyAPI.list();
      setPolicies(data);
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not load the policy catalog."));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    return policies.filter((p) => {
      const matchesType = typeFilter === "ALL" || p.policyType === typeFilter;
      const matchesQuery = !query || p.policyName.toLowerCase().includes(query.toLowerCase());
      return matchesType && matchesQuery;
    });
  }, [policies, typeFilter, query]);

  function openCreate() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setEditOpen(true);
  }

  function openEdit(policy) {
    setEditing(policy);
    setForm({
      policyName: policy.policyName,
      policyType: policy.policyType,
      description: policy.description,
      basePremiumAmount: policy.basePremiumAmount,
      coverageAmount: policy.coverageAmount,
    });
    setEditOpen(true);
  }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        ...form,
        basePremiumAmount: Number(form.basePremiumAmount),
        coverageAmount: Number(form.coverageAmount),
      };
      if (editing) {
        await PolicyAPI.update(editing.policyId, payload);
        toast.success("Policy updated.");
      } else {
        await PolicyAPI.create(payload);
        toast.success("Policy added to the catalog.");
      }
      setEditOpen(false);
      load();
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not save the policy."));
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(policy) {
    if (!window.confirm(`Remove "${policy.policyName}" from the catalog?`)) return;
    try {
      await PolicyAPI.remove(policy.policyId);
      toast.success("Policy removed.");
      load();
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not remove the policy."));
    }
  }

  function openPurchase(policy) {
    setPurchaseTarget(policy);
    setPurchaseForm({
      customerId: getLinkedCustomerId(user?.username) || "",
      startDate: new Date().toISOString().slice(0, 10),
      endDate: "",
    });
    setPurchaseOpen(true);
  }

  async function handlePurchase(e) {
    e.preventDefault();
    setPurchasing(true);
    try {
      await PolicyAPI.purchase({
        customerId: Number(purchaseForm.customerId),
        policyId: purchaseTarget.policyId,
        startDate: purchaseForm.startDate,
        endDate: purchaseForm.endDate,
      });
      toast.success(`${purchaseTarget.policyName} purchased.`);
      setPurchaseOpen(false);
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not complete the purchase."));
    } finally {
      setPurchasing(false);
    }
  }

  return (
    <div>
      <PageHeader
        eyebrow="Catalog"
        title="Policy Catalog"
        action={
          canManage && (
            <button className="btn-brass" onClick={openCreate}>
              + New policy
            </button>
          )
        }
      />

      <div className="flex flex-wrap gap-3 mb-5">
        <input
          className="field-input max-w-xs"
          placeholder="Search by name…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <select className="field-input max-w-[10rem]" value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
          <option value="ALL">All types</option>
          {POLICY_TYPES.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
      </div>

      {loading ? (
        <Loading label="Loading catalog" />
      ) : filtered.length === 0 ? (
        <EmptyState title="No policies found" hint="Try a different search or filter." />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((p) => (
            <div key={p.policyId} className="card p-5 flex flex-col">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-[10px] font-mono uppercase tracking-widest text-brass-600">{p.policyType}</div>
                  <h3 className="font-display text-lg leading-snug mt-0.5">{p.policyName}</h3>
                </div>
                <span className="id-mono shrink-0">#{p.policyId}</span>
              </div>
              <p className="text-sm text-ink-700/80 mt-2 flex-1">{p.description}</p>
              <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
                <div>
                  <div className="text-[10px] uppercase tracking-wide text-ink-600/60">Premium</div>
                  <Money value={p.basePremiumAmount} />
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wide text-ink-600/60">Coverage</div>
                  <Money value={p.coverageAmount} />
                </div>
              </div>
              <div className="flex gap-2 mt-4 pt-4 border-t border-ink-900/10">
                {canPurchase && (
                  <button className="btn-brass flex-1" onClick={() => openPurchase(p)}>
                    Purchase
                  </button>
                )}
                {canManage && (
                  <>
                    <button className="btn-outline flex-1" onClick={() => openEdit(p)}>Edit</button>
                    <button className="btn-danger" onClick={() => handleDelete(p)}>Delete</button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={editOpen} onClose={() => setEditOpen(false)} title={editing ? "Edit policy" : "New policy"}>
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="field-label">Policy name</label>
            <input
              className="field-input"
              value={form.policyName}
              onChange={(e) => setForm((f) => ({ ...f, policyName: e.target.value }))}
              required
            />
          </div>
          <div>
            <label className="field-label">Type</label>
            <select
              className="field-input"
              value={form.policyType}
              onChange={(e) => setForm((f) => ({ ...f, policyType: e.target.value }))}
            >
              {POLICY_TYPES.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="field-label">Description</label>
            <textarea
              className="field-input"
              rows={3}
              value={form.description}
              onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="field-label">Base premium</label>
              <input
                type="number"
                min="0"
                step="0.01"
                className="field-input"
                value={form.basePremiumAmount}
                onChange={(e) => setForm((f) => ({ ...f, basePremiumAmount: e.target.value }))}
                required
              />
            </div>
            <div>
              <label className="field-label">Coverage amount</label>
              <input
                type="number"
                min="0"
                step="0.01"
                className="field-input"
                value={form.coverageAmount}
                onChange={(e) => setForm((f) => ({ ...f, coverageAmount: e.target.value }))}
                required
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" className="btn-ghost" onClick={() => setEditOpen(false)}>Cancel</button>
            <button type="submit" disabled={saving} className="btn-primary">
              {saving ? "Saving…" : editing ? "Save changes" : "Add policy"}
            </button>
          </div>
        </form>
      </Modal>

      <Modal open={purchaseOpen} onClose={() => setPurchaseOpen(false)} title={`Purchase — ${purchaseTarget?.policyName || ""}`}>
        <form onSubmit={handlePurchase} className="space-y-4">
          <div>
            <label className="field-label">Your customer ID</label>
            <input
              type="number"
              className="field-input"
              value={purchaseForm.customerId}
              onChange={(e) => setPurchaseForm((f) => ({ ...f, customerId: e.target.value }))}
              required
            />
            <p className="text-xs text-ink-600/60 mt-1">
              Found on your customer record. Ask an agent if you don't have one yet.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="field-label">Start date</label>
              <input
                type="date"
                className="field-input"
                value={purchaseForm.startDate}
                onChange={(e) => setPurchaseForm((f) => ({ ...f, startDate: e.target.value }))}
                required
              />
            </div>
            <div>
              <label className="field-label">End date</label>
              <input
                type="date"
                className="field-input"
                value={purchaseForm.endDate}
                onChange={(e) => setPurchaseForm((f) => ({ ...f, endDate: e.target.value }))}
                required
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" className="btn-ghost" onClick={() => setPurchaseOpen(false)}>Cancel</button>
            <button type="submit" disabled={purchasing} className="btn-brass">
              {purchasing ? "Purchasing…" : "Confirm purchase"}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
