import { useEffect, useState } from "react";
import { AuthAPI, extractErrorMessage } from "../api/client";
import { useToast } from "../context/ToastContext";
import { PageHeader, EmptyState, Loading } from "../components/Ui";
import StatusStamp from "../components/StatusStamp";
import Modal from "../components/Modal";
import { formatDateTime } from "../utils/format";

export default function AdminRequests() {
  const toast = useToast();
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("PENDING");

  const [decisionTarget, setDecisionTarget] = useState(null); // { request, action }
  const [reason, setReason] = useState("");
  const [acting, setActing] = useState(false);

  async function load() {
    setLoading(true);
    try {
      setRequests(await AuthAPI.adminRequests(statusFilter === "ALL" ? undefined : statusFilter));
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not load admin requests."));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusFilter]);

  function openDecision(request, action) {
    setDecisionTarget({ request, action });
    setReason("");
  }

  async function runDecision() {
    if (!decisionTarget) return;
    const { request, action } = decisionTarget;
    setActing(true);
    try {
      if (action === "accept") await AuthAPI.acceptAdminRequest(request.id, reason || undefined);
      else await AuthAPI.denyAdminRequest(request.id, reason || undefined);
      toast.success(action === "accept" ? "Admin request accepted." : "Admin request denied.");
      setDecisionTarget(null);
      load();
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not record your decision."));
    } finally {
      setActing(false);
    }
  }

  return (
    <div>
      <PageHeader eyebrow="Master admin" title="Admin Registration Requests" />

      <div className="flex flex-wrap gap-3 mb-5">
        <select className="field-input max-w-[10rem]" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="PENDING">Pending</option>
          <option value="ACCEPTED">Accepted</option>
          <option value="DENIED">Denied</option>
          <option value="ALL">All</option>
        </select>
      </div>

      {loading ? (
        <Loading label="Loading requests" />
      ) : requests.length === 0 ? (
        <EmptyState title="No requests here" hint="New admin sign-ups will show up in this queue." />
      ) : (
        <div className="table-wrap">
          <table className="ledger">
            <thead>
              <tr>
                <th>Applicant</th>
                <th>Email</th>
                <th>Requested</th>
                <th>Status</th>
                <th>Reviewed</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {requests.map((r) => (
                <tr key={r.id}>
                  <td className="font-medium text-ink-900">{r.username}</td>
                  <td>{r.email}</td>
                  <td className="text-xs">{formatDateTime(r.createdAt)}</td>
                  <td><StatusStamp status={r.status} /></td>
                  <td className="text-xs text-ink-600/60">
                    {r.reviewedBy ? `${r.reviewedBy} · ${formatDateTime(r.reviewedAt)}` : "—"}
                  </td>
                  <td>
                    {r.status === "PENDING" && (
                      <div className="flex gap-2 justify-end">
                        <button className="btn-brass !py-1 !px-2 text-xs" onClick={() => openDecision(r, "accept")}>Accept</button>
                        <button className="btn-danger !py-1 !px-2 text-xs" onClick={() => openDecision(r, "deny")}>Deny</button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal
        open={!!decisionTarget}
        onClose={() => setDecisionTarget(null)}
        title={`${decisionTarget?.action === "accept" ? "Accept" : "Deny"} — ${decisionTarget?.request?.username ?? ""}`}
      >
        <div className="space-y-4">
          <div>
            <label className="field-label">Reason (optional)</label>
            <textarea className="field-input" rows={3} value={reason} onChange={(e) => setReason(e.target.value)} />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" className="btn-ghost" onClick={() => setDecisionTarget(null)}>Cancel</button>
            <button
              type="button"
              disabled={acting}
              onClick={runDecision}
              className={decisionTarget?.action === "accept" ? "btn-brass" : "btn-danger"}
            >
              {acting ? "Saving…" : decisionTarget?.action === "accept" ? "Accept request" : "Deny request"}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
