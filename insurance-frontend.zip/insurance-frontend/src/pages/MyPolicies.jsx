import { useEffect, useState } from "react";
import { PolicyAPI, extractErrorMessage } from "../api/client";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import { PageHeader, EmptyState, Loading, Money } from "../components/Ui";
import StatusStamp from "../components/StatusStamp";
import { formatDate } from "../utils/format";
import { getLinkedCustomerId, setLinkedCustomerId } from "../utils/customerLink";

export default function MyPolicies() {
  const { user } = useAuth();
  const toast = useToast();
  const [customerId, setCustomerId] = useState(getLinkedCustomerId(user?.username) || "");
  const [purchases, setPurchases] = useState([]);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);

  async function load(id) {
    if (!id) return;
    setLoading(true);
    try {
      const data = await PolicyAPI.byCustomer(id);
      setPurchases(data);
      setLoaded(true);
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not load your policies."));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (customerId) load(customerId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function handleLink(e) {
    e.preventDefault();
    setLinkedCustomerId(user?.username, customerId);
    load(customerId);
  }

  async function handleRenew(purchaseId) {
    try {
      await PolicyAPI.renew(purchaseId);
      toast.success("Policy renewed for another term.");
      load(customerId);
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not renew this policy."));
    }
  }

  async function handleCancel(purchaseId) {
    if (!window.confirm("Cancel this policy? This cannot be undone.")) return;
    try {
      await PolicyAPI.cancel(purchaseId);
      toast.success("Policy cancelled.");
      load(customerId);
    } catch (err) {
      toast.error(extractErrorMessage(err, "Could not cancel this policy."));
    }
  }

  return (
    <div>
      <PageHeader eyebrow="Your coverage" title="My Policies" />

      <div className="card p-5 mb-6">
        <form onSubmit={handleLink} className="flex flex-wrap items-end gap-3">
          <div>
            <label className="field-label">Your customer ID</label>
            <input
              type="number"
              className="field-input w-40"
              value={customerId}
              onChange={(e) => setCustomerId(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn-outline">View my policies</button>
          <p className="text-xs text-ink-600/60 ml-1">
            Links this browser to your customer record. An agent can confirm your ID.
          </p>
        </form>
      </div>

      {loading ? (
        <Loading label="Loading your policies" />
      ) : !loaded ? (
        <EmptyState title="Enter your customer ID above" hint="We'll pull every policy you've purchased." />
      ) : purchases.length === 0 ? (
        <EmptyState title="No policies yet" hint="Head to the Policy Catalog to purchase your first plan." />
      ) : (
        <div className="table-wrap">
          <table className="ledger">
            <thead>
              <tr>
                <th>Policy</th>
                <th>Number</th>
                <th>Term</th>
                <th>Premium</th>
                <th>Coverage</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {purchases.map((p) => (
                <tr key={p.purchaseId}>
                  <td>
                    <div className="font-medium text-ink-900">{p.policyName}</div>
                    <div className="text-xs text-ink-600/60">{p.policyType}</div>
                  </td>
                  <td className="id-mono">{p.policyNumber}</td>
                  <td className="text-xs">{formatDate(p.startDate)} – {formatDate(p.endDate)}</td>
                  <td><Money value={p.premiumAmount} /></td>
                  <td><Money value={p.coverageAmount} /></td>
                  <td><StatusStamp status={p.policyStatus} /></td>
                  <td>
                    <div className="flex gap-2 justify-end">
                      <button className="btn-outline !py-1 !px-2 text-xs" onClick={() => handleRenew(p.purchaseId)}>
                        Renew
                      </button>
                      <button className="btn-danger !py-1 !px-2 text-xs" onClick={() => handleCancel(p.purchaseId)}>
                        Cancel
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
