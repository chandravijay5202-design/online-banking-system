import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthAPI, extractErrorMessage } from "../api/client";
import { useToast } from "../context/ToastContext";
import AuthShell from "../components/AuthShell";

export default function ForgotPassword() {
  const toast = useToast();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const res = await AuthAPI.forgotPassword({ email });
      toast.success("Reset token generated.");
      navigate("/reset-password", { state: { token: res.resetToken } });
    } catch (err) {
      setError(extractErrorMessage(err, "Could not generate a reset token."));
    } finally {
      setBusy(false);
    }
  }

  return (
    <AuthShell
      eyebrow="Password recovery"
      title="Forgot your password?"
      subtitle="We'll generate a reset token valid for 15 minutes."
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="field-label" htmlFor="email">Email</label>
          <input
            id="email"
            type="email"
            className="field-input"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        {error && <p className="field-error">{error}</p>}
        <button type="submit" disabled={busy} className="btn-primary w-full">
          {busy ? "Generating…" : "Generate reset token"}
        </button>
      </form>
      <p className="mt-5 text-center text-sm text-ink-700/70">
        <Link to="/login" className="hover:text-brass-600 font-medium">Back to sign in</Link>
      </p>
    </AuthShell>
  );
}
