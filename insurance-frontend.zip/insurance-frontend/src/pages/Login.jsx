import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import { extractErrorMessage } from "../api/client";
import AuthShell from "../components/AuthShell";

export default function Login() {
  const { login } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ username: "", password: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const res = await login(form.username.trim(), form.password);
      toast.success(`Welcome back, ${res.username}.`);
      const dest = location.state?.from?.pathname || "/app";
      navigate(dest, { replace: true });
    } catch (err) {
      setError(extractErrorMessage(err, "Could not sign in. Check your credentials."));
    } finally {
      setBusy(false);
    }
  }

  return (
    <AuthShell
      eyebrow="Underwriting Console"
      title="Sign in to your ledger"
      subtitle="Policies, claims and tickets, all under one seal."
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="field-label" htmlFor="username">Username</label>
          <input
            id="username"
            className="field-input"
            autoComplete="username"
            value={form.username}
            onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))}
            required
          />
        </div>
        <div>
          <label className="field-label" htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            className="field-input"
            autoComplete="current-password"
            value={form.password}
            onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
            required
          />
        </div>
        {error && <p className="field-error">{error}</p>}
        <button type="submit" disabled={busy} className="btn-primary w-full">
          {busy ? "Signing in…" : "Sign in"}
        </button>
      </form>

      <div className="mt-5 flex items-center justify-between text-sm text-ink-700/70">
        <Link to="/forgot-password" className="hover:text-brass-600">Forgot password?</Link>
        <Link to="/register" className="hover:text-brass-600">Create an account</Link>
      </div>
    </AuthShell>
  );
}
