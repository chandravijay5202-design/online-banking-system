// The auth-service User and the customer-service Customer are separate
// records (different microservices, no shared key). Until the backend
// links them, a signed-in CUSTOMER points at "their" Customer record by
// remembering its id locally, keyed by username.

function key(username) {
  return `ima_customer_link:${username}`;
}

export function getLinkedCustomerId(username) {
  if (!username) return null;
  const raw = localStorage.getItem(key(username));
  return raw ? Number(raw) : null;
}

export function setLinkedCustomerId(username, customerId) {
  if (!username) return;
  localStorage.setItem(key(username), String(customerId));
}

export function clearLinkedCustomerId(username) {
  if (!username) return;
  localStorage.removeItem(key(username));
}
