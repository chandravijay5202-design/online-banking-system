import axios from "axios";

// The API gateway is the single entry point for every microservice
// (auth, customers, policies, claims, support, notifications).
// Override with VITE_API_BASE_URL in a .env file if the gateway
// isn't running on localhost:8081.
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8081";

export const client = axios.create({
  baseURL: API_BASE_URL,
  headers: { "Content-Type": "application/json" },
});

client.interceptors.request.use((config) => {
  const token = localStorage.getItem("ima_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

client.interceptors.response.use(
  (res) => res,
  (error) => {
    if (error.response?.status === 401) {
      // Token missing/expired/invalid — force a clean re-login.
      localStorage.removeItem("ima_token");
      localStorage.removeItem("ima_user");
      if (!window.location.pathname.startsWith("/login")) {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

// Pulls a readable message out of the backend's error shape
// (GlobalExceptionHandler-style bodies, or field validation maps).
export function extractErrorMessage(error, fallback = "Something went wrong. Please try again.") {
  const data = error?.response?.data;
  if (!data) return error?.message || fallback;
  if (typeof data === "string") return data;
  if (data.message) return data.message;
  if (data.errors && typeof data.errors === "object") {
    const first = Object.values(data.errors)[0];
    if (first) return Array.isArray(first) ? first[0] : String(first);
  }
  if (data.error) return data.error;
  return fallback;
}

// ── Auth ──────────────────────────────────────────────────────────────
export const AuthAPI = {
  login: (payload) => client.post("/auth/login", payload).then((r) => r.data),
  register: (payload) => client.post("/auth/register", payload).then((r) => r.data),
  forgotPassword: (payload) => client.post("/auth/forgot-password", payload).then((r) => r.data),
  resetPassword: (payload) => client.post("/auth/reset-password", payload).then((r) => r.data),
  profile: () => client.get("/auth/profile").then((r) => r.data),
  adminRequests: (status) =>
    client.get("/auth/admin-requests", { params: status ? { status } : {} }).then((r) => r.data),
  acceptAdminRequest: (id, reason) =>
    client.put(`/auth/admin-requests/${id}/accept`, reason ? { reason } : {}).then((r) => r.data),
  denyAdminRequest: (id, reason) =>
    client.put(`/auth/admin-requests/${id}/deny`, reason ? { reason } : {}).then((r) => r.data),
};

// ── Customers ─────────────────────────────────────────────────────────
export const CustomerAPI = {
  list: () => client.get("/customers").then((r) => r.data),
  get: (id) => client.get(`/customers/${id}`).then((r) => r.data),
  create: (payload) => client.post("/customers", payload).then((r) => r.data),
  update: (id, payload) => client.put(`/customers/${id}`, payload).then((r) => r.data),
  remove: (id) => client.delete(`/customers/${id}`).then((r) => r.data),
};

// ── Policies ──────────────────────────────────────────────────────────
export const PolicyAPI = {
  list: () => client.get("/policies").then((r) => r.data),
  get: (id) => client.get(`/policies/${id}`).then((r) => r.data),
  create: (payload) => client.post("/policies", payload).then((r) => r.data),
  update: (id, payload) => client.put(`/policies/${id}`, payload).then((r) => r.data),
  remove: (id) => client.delete(`/policies/${id}`).then((r) => r.data),
  purchase: (payload) => client.post("/policies/purchase", payload).then((r) => r.data),
  getPurchased: (purchaseId) => client.get(`/policies/purchased/${purchaseId}`).then((r) => r.data),
  byCustomer: (customerId) => client.get(`/policies/customer/${customerId}`).then((r) => r.data),
  renew: (purchaseId) => client.put(`/policies/renew/${purchaseId}`).then((r) => r.data),
  cancel: (purchaseId) => client.delete(`/policies/cancel/${purchaseId}`).then((r) => r.data),
};

// ── Claims ────────────────────────────────────────────────────────────
export const ClaimAPI = {
  submit: (payload) => client.post("/claims", payload).then((r) => r.data),
  list: () => client.get("/claims").then((r) => r.data),
  get: (id) => client.get(`/claims/${id}`).then((r) => r.data),
  byCustomer: (customerId) => client.get(`/claims/customer/${customerId}`).then((r) => r.data),
  markUnderReview: (id) => client.put(`/claims/${id}/review`).then((r) => r.data),
  approve: (id, remarks) => client.put(`/claims/${id}/approve`, remarks ? { remarks } : {}).then((r) => r.data),
  reject: (id, remarks) => client.put(`/claims/${id}/reject`, remarks ? { remarks } : {}).then((r) => r.data),
  settle: (id, remarks) => client.put(`/claims/${id}/settle`, remarks ? { remarks } : {}).then((r) => r.data),
};

// ── Support tickets ───────────────────────────────────────────────────
export const SupportAPI = {
  create: (payload) => client.post("/support/tickets", payload).then((r) => r.data),
  get: (ticketId) => client.get(`/support/tickets/${ticketId}`).then((r) => r.data),
  list: () => client.get("/support/tickets").then((r) => r.data),
  byCustomer: (customerId) => client.get(`/support/tickets/customer/${customerId}`).then((r) => r.data),
  markInProgress: (ticketId, remarks) =>
    client.patch(`/support/tickets/${ticketId}/in-progress`, null, { params: remarks ? { remarks } : {} }).then((r) => r.data),
  resolve: (ticketId, remarks) =>
    client.patch(`/support/tickets/${ticketId}/resolve`, null, { params: remarks ? { remarks } : {} }).then((r) => r.data),
  close: (ticketId, remarks) =>
    client.patch(`/support/tickets/${ticketId}/close`, null, { params: remarks ? { remarks } : {} }).then((r) => r.data),
};

// ── Notifications ─────────────────────────────────────────────────────
export const NotificationAPI = {
  send: (payload) => client.post("/notifications/send", payload).then((r) => r.data),
  byCustomer: (customerId) => client.get(`/notifications/customer/${customerId}`).then((r) => r.data),
};
