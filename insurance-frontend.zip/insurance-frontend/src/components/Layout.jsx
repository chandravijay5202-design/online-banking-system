import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const NAV = [
  { to: "/app", label: "Overview", roles: ["CUSTOMER", "AGENT", "ADMIN", "MASTER_ADMIN"], end: true },
  { to: "/app/policies", label: "Policy Catalog", roles: ["CUSTOMER", "AGENT", "ADMIN", "MASTER_ADMIN"] },
  { to: "/app/my-policies", label: "My Policies", roles: ["CUSTOMER"] },
  { to: "/app/claims", label: "Claims", roles: ["CUSTOMER", "AGENT", "ADMIN", "MASTER_ADMIN"] },
  { to: "/app/customers", label: "Customers", roles: ["AGENT", "ADMIN", "MASTER_ADMIN"] },
  { to: "/app/support", label: "Support Desk", roles: ["CUSTOMER", "AGENT", "ADMIN", "MASTER_ADMIN"] },
  { to: "/app/notifications", label: "Notifications", roles: ["CUSTOMER", "AGENT", "ADMIN", "MASTER_ADMIN"] },
  { to: "/app/admin-requests", label: "Admin Requests", roles: ["MASTER_ADMIN"] },
];

export default function Layout() {
  const { user, role, logout } = useAuth();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate("/login");
  }

  const items = NAV.filter((n) => n.roles.includes(role));

  return (
    <div className="min-h-screen flex bg-parchment-100">
      <aside className="w-64 shrink-0 bg-ink-950 text-parchment-100 flex flex-col">
        <div className="px-6 py-6 border-b border-parchment-100/10">
          <div className="flex items-center gap-2">
            <span className="h-8 w-8 rounded-full border-2 border-brass-400 flex items-center justify-center font-display text-brass-400 text-sm -rotate-3">
              MA
            </span>
            <div>
              <div className="font-display text-lg leading-none">Meridian Assure</div>
              <div className="text-[10px] uppercase tracking-widest text-parchment-100/40 mt-0.5">Underwriting Console</div>
            </div>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {items.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `block rounded-md px-3 py-2 text-sm transition-colors ${
                  isActive
                    ? "bg-brass-500/15 text-brass-400 font-medium"
                    : "text-parchment-100/70 hover:bg-white/5 hover:text-parchment-100"
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="px-4 py-4 border-t border-parchment-100/10">
          <div className="flex items-center justify-between gap-2">
            <div className="min-w-0">
              <div className="text-sm font-medium truncate">{user?.username}</div>
              <div className="text-[10px] font-mono uppercase tracking-wider text-brass-400">{role}</div>
            </div>
            <button onClick={handleLogout} className="btn-ghost !text-parchment-100/70 !px-2 text-xs hover:!text-parchment-100">
              Sign out
            </button>
          </div>
        </div>
      </aside>

      <main className="flex-1 min-w-0">
        <div className="max-w-6xl mx-auto px-6 md:px-10 py-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
