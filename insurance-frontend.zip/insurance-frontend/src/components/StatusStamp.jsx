const TONE_MAP = {
  // Policies
  ACTIVE: "active",
  EXPIRED: "neutral",
  CANCELLED: "negative",
  // Claims
  SUBMITTED: "pending",
  UNDER_REVIEW: "pending",
  APPROVED: "active",
  REJECTED: "negative",
  SETTLED: "active",
  // Tickets
  OPEN: "pending",
  IN_PROGRESS: "pending",
  RESOLVED: "active",
  CLOSED: "neutral",
  // Admin requests
  PENDING: "pending",
  ACCEPTED: "active",
  DENIED: "negative",
};

export default function StatusStamp({ status }) {
  if (!status) return null;
  const tone = TONE_MAP[status] || "neutral";
  return <span className={`stamp stamp-${tone}`}>{status.replace(/_/g, " ")}</span>;
}
