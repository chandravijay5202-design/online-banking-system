export function PageHeader({ eyebrow, title, action }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
      <div>
        {eyebrow && (
          <div className="text-xs font-mono uppercase tracking-widest text-brass-600 mb-1">{eyebrow}</div>
        )}
        <h1 className="text-2xl md:text-3xl font-semibold">{title}</h1>
      </div>
      {action}
    </div>
  );
}

export function EmptyState({ title, hint }) {
  return (
    <div className="card p-10 text-center">
      <p className="font-display text-lg text-ink-800">{title}</p>
      {hint && <p className="text-sm text-ink-600/70 mt-1">{hint}</p>}
    </div>
  );
}

export function Loading({ label = "Loading" }) {
  return (
    <div className="flex items-center gap-2 text-sm text-ink-600/70 py-10 justify-center">
      <span className="h-2 w-2 rounded-full bg-brass-500 animate-bounce [animation-delay:-0.2s]" />
      <span className="h-2 w-2 rounded-full bg-brass-500 animate-bounce [animation-delay:-0.1s]" />
      <span className="h-2 w-2 rounded-full bg-brass-500 animate-bounce" />
      <span className="ml-2">{label}…</span>
    </div>
  );
}

export function Money({ value }) {
  if (value == null) return <span>—</span>;
  return (
    <span className="font-mono">
      {new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value)}
    </span>
  );
}
