export default function AuthShell({ eyebrow, title, subtitle, children }) {
  return (
    <div className="min-h-screen bg-ink-950 flex items-center justify-center px-4 py-10 relative overflow-hidden">
      {/* Ambient ledger lines */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "repeating-linear-gradient(180deg, transparent, transparent 35px, #D8AA5C 36px)",
        }}
      />
      <div className="relative w-full max-w-md">
        <div className="flex items-center gap-3 justify-center mb-8">
          <span className="h-11 w-11 rounded-full border-2 border-brass-400 flex items-center justify-center font-display text-brass-400 text-base -rotate-3">
            MA
          </span>
          <div>
            <div className="font-display text-xl text-parchment-50 leading-none">Meridian Assure</div>
            <div className="text-[10px] uppercase tracking-widest text-parchment-100/40 mt-1">
              Insurance Management System
            </div>
          </div>
        </div>

        <div className="card !bg-parchment-50 p-8">
          {eyebrow && (
            <div className="text-xs font-mono uppercase tracking-widest text-brass-600 mb-2">{eyebrow}</div>
          )}
          <h1 className="text-2xl font-semibold mb-1">{title}</h1>
          {subtitle && <p className="text-sm text-ink-600/70 mb-6">{subtitle}</p>}
          {!subtitle && <div className="mb-6" />}
          {children}
        </div>

        <p className="text-center text-parchment-100/30 text-xs mt-6 font-mono">
          Policy documents are legal ledgers — sign with care.
        </p>
      </div>
    </div>
  );
}
