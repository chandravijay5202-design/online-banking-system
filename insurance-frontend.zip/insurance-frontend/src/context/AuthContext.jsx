import { createContext, useContext, useEffect, useMemo, useState, useCallback } from "react";
import { jwtDecode } from "jwt-decode";
import { AuthAPI } from "../api/client";

const AuthContext = createContext(null);

function decodeUser(token) {
  try {
    const claims = jwtDecode(token);
    return {
      username: claims.sub,
      role: (claims.role || "CUSTOMER").toUpperCase(),
      exp: claims.exp,
    };
  } catch {
    return null;
  }
}

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem("ima_token"));
  const [user, setUser] = useState(() => {
    const t = localStorage.getItem("ima_token");
    return t ? decodeUser(t) : null;
  });
  const [profile, setProfile] = useState(null);

  // Keep tabs/reloads in sync and clear expired sessions on load.
  useEffect(() => {
    if (token) {
      const decoded = decodeUser(token);
      if (decoded && decoded.exp * 1000 > Date.now()) {
        setUser(decoded);
      } else {
        logout();
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = useCallback(async (username, password) => {
    const res = await AuthAPI.login({ username, password });
    localStorage.setItem("ima_token", res.token);
    localStorage.setItem("ima_user", JSON.stringify({ username: res.username, role: res.role }));
    setToken(res.token);
    setUser(decodeUser(res.token));
    return res;
  }, []);

  const register = useCallback(async (payload) => {
    return AuthAPI.register(payload);
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem("ima_token");
    localStorage.removeItem("ima_user");
    setToken(null);
    setUser(null);
    setProfile(null);
  }, []);

  const loadProfile = useCallback(async () => {
    const p = await AuthAPI.profile();
    setProfile(p);
    return p;
  }, []);

  const value = useMemo(
    () => ({
      token,
      user,
      profile,
      isAuthenticated: !!user,
      role: user?.role || null,
      login,
      register,
      logout,
      loadProfile,
    }),
    [token, user, profile, login, register, logout, loadProfile]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
