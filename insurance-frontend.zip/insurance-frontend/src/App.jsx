import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { ToastProvider } from "./context/ToastContext";
import ProtectedRoute from "./components/ProtectedRoute";
import Layout from "./components/Layout";

import Login from "./pages/Login";
import Register from "./pages/Register";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import Overview from "./pages/Overview";
import PolicyCatalog from "./pages/PolicyCatalog";
import MyPolicies from "./pages/MyPolicies";
import Claims from "./pages/Claims";
import Customers from "./pages/Customers";
import Support from "./pages/Support";
import Notifications from "./pages/Notifications";
import AdminRequests from "./pages/AdminRequests";

function RootRedirect() {
  const { isAuthenticated } = useAuth();
  return <Navigate to={isAuthenticated ? "/app" : "/login"} replace />;
}

function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-ink-950 text-parchment-100 text-center px-4">
      <div>
        <div className="font-display text-5xl mb-2">404</div>
        <p className="text-parchment-100/60">This page isn't in the ledger.</p>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <Routes>
            <Route path="/" element={<RootRedirect />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />

            <Route
              path="/app"
              element={
                <ProtectedRoute>
                  <Layout />
                </ProtectedRoute>
              }
            >
              <Route index element={<Overview />} />
              <Route path="policies" element={<PolicyCatalog />} />
              <Route
                path="my-policies"
                element={
                  <ProtectedRoute roles={["CUSTOMER"]}>
                    <MyPolicies />
                  </ProtectedRoute>
                }
              />
              <Route path="claims" element={<Claims />} />
              <Route
                path="customers"
                element={
                  <ProtectedRoute roles={["AGENT", "ADMIN", "MASTER_ADMIN"]}>
                    <Customers />
                  </ProtectedRoute>
                }
              />
              <Route path="support" element={<Support />} />
              <Route path="notifications" element={<Notifications />} />
              <Route
                path="admin-requests"
                element={
                  <ProtectedRoute roles={["MASTER_ADMIN"]}>
                    <AdminRequests />
                  </ProtectedRoute>
                }
              />
            </Route>

            <Route path="*" element={<NotFound />} />
          </Routes>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
